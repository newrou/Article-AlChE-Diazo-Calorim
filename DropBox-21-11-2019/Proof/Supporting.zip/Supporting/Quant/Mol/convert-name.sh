
rename "s/-Ph-/C6H4/" *
rename "s/o-/2-/" *
rename "s/m-/3-/" *
rename "s/p-/4-/" *
rename "s/N2-F/N2\+ F-/" *
rename "s/N2-OTf/N2\+ TfO-/" *
rename "s/N2-BF4/N2\+ BF4-/" *
rename "s/N2-OTs/N2\+ TsO-/" *
rename "s/-RB3LYP/ RB3LYP/" *
